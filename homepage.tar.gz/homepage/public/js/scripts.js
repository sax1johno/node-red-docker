$('.dropdown')
  .dropdown({
    // you can use any ui transition
    transition: 'drop'
  });
  
$('.special.cards .image').dimmer({
  on: 'hover'
});