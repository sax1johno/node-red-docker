angular.module("us.propl", [
    "ui.router",
    "ui.grid",
    "ui.bootstrap",
    // "semantic-ui"
]).run(function($http, $rootScope) {
    $rootScope.alerts = [];
    $http.get("/api/v1/currentUser")
        .then(function(response) {
            if (response.status < 400) {
                console.log("username = ", response.data);
                $rootScope.user = response.data.user;
                $rootScope.userInfo = response.data;
            } else {
                alert("Invalid username");
            }
        })
    $rootScope.currentDate = new Date();
    
    $rootScope.closeAlert = function(index) {
        // console.log("Closing ", index);
        $rootScope.alerts.splice(index, 1);
    };
})