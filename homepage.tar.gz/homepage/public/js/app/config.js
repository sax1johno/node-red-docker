angular.module("us.propl")
.config(function($stateProvider, $urlRouterProvider, $interpolateProvider) {
    // Change to triple-bracket syntax for Angular since it collides with double-brackets for Nunjucks (backend template engine);
    $interpolateProvider.startSymbol('{{{').endSymbol('}}}');
    
    $stateProvider
        .state('index', {
            abstract: true,
            url: "/home",
            templateUrl: "views/common/content.html",
        })
        .state('index.dashboard', {
            url: "/dashboard",
            templateUrl: "views/dashboard.html",
            controller: "DashboardController"
        })
    
        .state('sites', {
            abstract: true,
            url: "/sites",
            templateUrl: "views/common/content.html",
        })
        .state("sites.list", {
            templateUrl: "/views/siteList.html",
            controller: "SiteListingController",
            url: "/list"
        })
        .state("sites.create", {
            templateUrl: "/views/siteCreate.html",
            controller: "SiteCreateController",
            url: "/create"
        })
        .state("sites.edit", {
            templateUrl: "/views/siteEdit.html",
            controller: "SiteEditController",
            url: "/edit/:_id",
            params: {
                _id: null
            }
        })
        .state('account', {
            abstract: true,
            url: "/account",
            templateUrl: "views/common/content.html",
        })
        .state('account.settings', {
            "templateUrl": "/views/accountSettings.html",
            "controller": "AccountSettingsController",
            "url": "/settings"
        })
        .state('account.billing', {
            "templateUrl": "/views/accountBilling.html",
            "controller": "AccountBillingController",
            "url": "/billing"
        });

    $urlRouterProvider.otherwise('/sites/list');
});