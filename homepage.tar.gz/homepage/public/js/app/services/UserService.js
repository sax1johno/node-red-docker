angular.module("us.propl")
    .factory("User", function($http) {
        //   return {
        //       getCurrentUser: function() {
        //           return $http.get('users.json').then(
        //               function(result) {
        //                   users = result.data;
        //                   return users;
        //               },
        //               function(error) {
        //                   users = [];
        //                   console.log(error);
        //               }
        //           );
        //       },
        //       add: function(user) {
        //           users.push(user);
        //       },
        //       remove: function(user) {
        //           for(var i = 0; i < users.length; i++) {
        //               if(users[i].id === user.id) { // use whatever you want to determine equality
        //                   users.splice(i, 1);
        //                   return;
        //               }
        //           }
        //       }
        //   };
        
    });