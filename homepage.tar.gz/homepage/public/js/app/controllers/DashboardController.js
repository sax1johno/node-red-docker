angular.module("us.propl")
    .controller("DashboardController", function($scope) {
        
    })