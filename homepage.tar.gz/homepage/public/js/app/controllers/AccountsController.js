angular.module("us.propl")
    .controller("AccountSettingsController", function($scope, $state, $http, $uibModal, $rootScope) {
        
        $http.get("/api/v1/currentUser")
            .then(function(response) {
                if (response.status < 400) {
                    $scope.updatedUser = response.data.user;
                    console.log("user = ", response.data);
                    // $rootScope.user = response.data.user;
                    // $rootScope.userInfo = response.data;
                } else {
                    // Handle bad currentUser / log them out.
                }
            });
        
        // $scope.updatedUser = angular.copy($rootScope.user);
        $scope.save = function() {
            console.log("Would have saved user with info", $scope.updatedUser)
            $http.put("/api/users/self", $scope.updatedUser)
                .then(function(response) {
                    if (response.status < 400) {
                        $rootScope.alerts.push({
                            "msg": "Updated User Info",
                            "type": "alert-success"
                        });
                    } else {
                        // alert("Couldn't get sites with code " + response.status);
                        $rootScope.alerts.push({
                            "msg": "User update failed: " + response.data,
                            "type": "alert-danger"
                        });
                    }
                }, function(response) {
                        $rootScope.alerts.push({
                            "msg": "User update failed: " + response.data,
                            "type": "alert-danger"
                        });

                })
        }
    })
    .controller("AccountBillingController", function($scope, $http, $state, $rootScope) {
        $scope.loading = "loading";
        
        $scope.refresh = function() {
            $http.get("/api/v1/billingInfo")
                .then(function(response) {
                    console.log(response);
                    if (response.data.sources) {
                        if (response.data.sources.total_count > 0) {
                            console.log("Sources was > 0");
                            console.log(response.data.sources.data);
                            for (var i = 0; i < response.data.sources.total_count; i++) {
                                console.log(response.data.sources.data[i].id);
                                console.log(response.data.default_source);
                                if (response.data.sources.data[i].id == response.data.default_source) {
                                    $scope.paymentSource = response.data.sources.data[i];
                                }
                            }
                        }
                    }
                    // console.log(response);
                }).then(function() {
    
                    $http.get("/api/v1/sites")
                        .then(function(response) {
                            // console.log("refresh", response);
                            if (response.status < 400) {
                                $scope.sites = response.data;
                                console.log($scope.sites);
                                $scope.freeSites = 0;
                                if ($scope.sites.length > 0) {
                                    $scope.freeSites = 1;
                                    $scope.paidSites = $scope.sites.length - 1;
                                } 
                                console.log($rootScope.userInfo);
                                // if ($rootScope.userInfo.plan.quota > 0 && $scope.sites.length >= $rootScope.userInfo.plan.quota) {
                                    // $scope.planLimitReached = true;
                                // } else {
                                    // $scope.planLimitReached = false;
                                // }
                                // for (var i = 0; i < $scope.sites; i++) {
                                //     $scope.sites[i].deployButton = {
                                //         "class": "",
                                //         "editMode": false
                                //     }
                                // }
                            }
                            else {
                                $rootScope.alerts.push({
                                    "msg": "Unable to retrieve sites" ,
                                    "type": "alert-danger"
                                });
                                // alert("Couldn't get sites with code " + response.status);
                            }
                            $scope.loading = "";
                        });
                        
                }).catch(function(err) {
                    console.error(err);
                    $scope.loading = "";
                })
        }
        
        $scope.removeBilling = function() {
            var answer = confirm("Are you sure you want to delete your payment method? You will no longer be able to create apps and apps exceeding your free plan will be paused.");
            if (answer) {
                $scope.loading = "loading";
                $http.delete("/api/v1/paymentMethod")
                    .then(function(response) {
                        if (response.status < 400) {
                            $rootScope.alerts.push({
                                "msg": "Payment info was removed" ,
                                "type": "alert-success"
                            });
                            $scope.refresh();
                        }
                    }).catch(function(response) {
                        $rootScope.alerts.push({
                            "msg": "Payment info was not removed. Please contact support (help.propl.us) to complete your payment removal",
                            "type": "alert-danger"
                        });
                        $scope.refresh();                        
                    })
            }
        }
        
        $scope.refresh();
    });
    // .controller("AccountListController", function($scope, $state, $http, $rootScope) {
    //     $http.get("/") 
    // });
