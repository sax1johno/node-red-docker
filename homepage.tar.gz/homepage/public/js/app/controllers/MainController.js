angular.module("us.propl")
    .controller("MainController", function($scope, $state, $http, $uibModal, $rootScope) {
        $scope.date = new Date();        
    })
    // .controller("AccountListController", function($scope, $state, $http, $rootScope) {
    //     $http.get("/") 
    // });
