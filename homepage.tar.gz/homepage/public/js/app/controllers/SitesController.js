angular.module("us.propl")
    .controller("SiteListingController", function($scope, $state, $http, $uibModal, $rootScope) {
        // $scope.sites = [
        //     {
        //         "name": "My Site",
        //         "url": "mysite",
        //         "_id": "abc123"
        //     }
        // ];

        // $http.get("/api/sites")
        //     .then(function(response) {
        //         console.log(response);
        //         if (response.status < 400) {
        //             $scope.sites = response.data;
        //         }
        //         else {
        //             alert("Couldn't get sites with code " + response.status);
        //         }
        //     });

        // $scope.username = $rootScope.user.username;
        // console.log($rootScope.userInfo);

        $scope.refresh = function() {
            $scope.pageLoading = "loading";
            $http.get("/api/v1/sites")
                .then(function(response) {
                    // console.log("refresh", response);
                    $scope.pageLoading = "";
                    if (response.status < 400) {
                        $scope.sites = response.data;
                        if ($scope.sites.length > 0 && !$rootScope.userInfo.user.billingOnFile) {
                            $scope.planLimitReached = true;
                        } else {
                            $scope.planLimitReached = false;
                        }
                        // if ($rootScope.userInfo.plan.quota > 0 && $scope.sites.length >= $rootScope.userInfo.plan.quota) {
                        //     $scope.planLimitReached = true;
                        // } else {
                        //     $scope.planLimitReached = false;
                        // }
                        // for (var i = 0; i < $scope.sites; i++) {
                        //     $scope.sites[i].deployButton = {
                        //         "class": "",
                        //         "editMode": false
                        //     }
                        // }
                    }
                    else {
                        alert("Couldn't get sites with code " + response.status);
                    }
                });
        };

        // $scope.deploy = function(site) {
        //     site.deployButton = {
        //         "class": "loading"
        //     };
        //     site.deployButton.disabled = true;
        //     $http.post("/api/v1/site/deploy/" + site._id)
        //         .then(function(response) {
        //             console.log(response);
        //             // alert("Should have deployed");
        //             // ng-disabled="site.undeployButton.disabled" ng-class="site.undeployButton.class"
        //             // alert("Error encountered " + response.status);
        //             $rootScope.alerts.push({
        //                 "msg": "Your site is being deployed.  This should take approximatly 1 minute."
        //             });
        //             // $scope.refresh();
        //             site.deployButton.disabled = true;
        //         }, function(err) {
        //             console.log(err);
        //             site.deployButton.class = "";
        //             site.deployButton.disabled = false;
        //         });
            
        //     setTimeout(function(){ 
        //         site.deployButton = {
        //             "class": ""
        //         };
        //         $scope.refresh();
        //     }, 60000);
            
        // };
        
        // $scope.undeploy = function(site) {
        //     var conf = confirm("Click OK to undeploy.  WARNING: Undeploying the site will delete the instance of this site and could potentially delete all data flows");
        //     if (conf) {
        //         $http.post("/api/v1/site/undeploy/" + site._id)
        //             .then(function(response) {
        //                 console.log(response);
        //                 alert("Should have removed deployment");
        //             });
        //     }
        // };


        $scope.delete = function(item) {
            var answer = confirm("Are you sure you want to delete?  This will remove the site and all flows within it. WARNING: This is NOT REVERSIBLE");
            if (answer) {
                item.deleteButton = {
                    "class": "loading"
                };
                $http.delete("/api/v1/site/" + item._id)
                    .then(function(res) {
                        if (res.status < 400) {
                            console.log(res.data);
                            $scope.refresh();
                            $rootScope.alerts.push({
                                "msg": "Successfully deleted site " + item.name,
                                "type": "alert-success"
                            });
                        } else {
                            $scope.refresh();
                            $rootScope.alerts.push({
                                "msg": "Successfully deleted site " + item.name,
                                "type": "alert-danger"
                            });
                        }
                    });
            }
        };

        // $scope.planLimitReached = false;
        
        console.log($scope.user);

        $scope.refresh();

        $scope.createSite = function() {
            // $http.post("/api/site", {
            //     "name": "MyNewSite"
            //     // "userName": $scope.username
            // }).then(function(response) {
            //     if (response.status < 400) {
            //         $scope.refresh();
            //     }
            //     else {
            //         alert("Error encountered " + response.status);
            //     }
            // });
            
            $state.go("sites.create");
        }

        $scope.save = function(site) {
            $scope.switchToViewMode(site);
            // var siteSend;
            // angular.copy(site, siteSend);
            // console.log(siteSend.editMode);
            delete site.editMode;
            console.log("Site = ", site);
            // delete site.deployButton;
            $http.put("/api/v1/site/" + site._id, site).then(function(res) {
                if (res.status < 400) {
                    $scope.refresh();
                } else {
                    alert("Error encountered " + res.status);
                }

                site.editMode = false;
            });
        };

        $scope.cancel = function(site) {
            angular.copy($scope.oldSiteData, site);
            delete $scope.oldSiteData;
            $scope.switchToViewMode(site);
        }

        $scope.keypress = function(event, site) {
            if (event.keyCode == 27) {
                $scope.cancel(site);
            }
        }

        $scope.switchToEditMode = function(site) {
            // if (!site.deployed) {
            $scope.oldSiteData = angular.copy(site);
            console.log("Site is ", site);
            console.log("Old site data is ", $scope.oldSiteData);
            site.editMode = true;
            // }
        }
        
        $scope.edit = function(site) {
            console.log("Would have edited site ", site);
            $state.go("sites.edit", {
                "_id": site._id,
            });
        }

        $scope.switchToViewMode = function(site) {
            site.editMode = false;
        }
    }).controller("SiteListItemController", function($scope, $http, $timeout, $interval) {
        $scope.$watch('site.name', function(newVal, oldVal) {
            $scope.site.url = [
                $scope.username + "-" + newVal.split(' ').join('').toLowerCase(),
                "propl",
                "us"
            ].join('.');
            
            console.log($scope.site.url);
            $scope.site.admin = $scope.site.url + "/system/admin";
            // TODO: get this from the token rather than the frontend.
            // {{site.name.split(' ').join('').toLowerCase()}}.{{username}}.propl.us             
        });
        
        console.log($scope.site);
        
        var getSiteInfo = function() {
            $http.get("/api/v1/siteInfo?_id=" + $scope.site._id)
                .then(function(response) {
                    $scope.site.status = response.data;
                    console.log(response.data);
                    // Execute every 10 seconds.
                    $scope.site.dimmer = $scope.site.status.state == "active" ? "" : "active";
                    if ($scope.site.status.transitioning == "no" && !$scope.site.status.state == "active") {
                        $scope.site.loadingMessage = "500 Error: Try back later";
                    } else if ($scope.site.status.state !== "active") {
                        $scope.site.loadingMessage = "Activating";
                        $timeout(getSiteInfo, 1000 * 10); // Try again in 10 seconds.
                    }
                }, function(response) {
                    console.log(response);
                });
        }
        
        getSiteInfo();
        
    }).controller("SiteCreateController", function($scope, $http, $state, $rootScope) {
        $scope.createSite = function() {
            $scope.creating = "loading";
            
            $http.post("/api/v1/site", {
                "name": $scope.site.name,
                "description": $scope.site.description,
                "adminUsername": $scope.site.adminUsername,
                "adminPassword": $scope.site.adminPassword
                // "userName": $scope.username
            }).then(function(response) {
                $scope.creating = "";
                if (response.status < 400) {
                    // $scope.refresh();
                    console.log("site", response);
                    $state.go("sites.list");
                }
                else {
                    // alert("Error encountered " + response.status);
                    $rootScope.alerts.push({
                        "msg": "Unable to create site: " + response.data,
                        "type": "alert-danger"
                    });
                }
            }).catch(function(response) {
                if (response.status == 402) {
                    $rootScope.alerts.push({
                        "msg": "Add or update your payment information to create another app",
                        "type": "alert-danger"
                    });
                    $scope.creating = "";
                    $state.go('account.billing');
                }
            })
            // $state.go("sites.create");
        }

    }).controller("SiteEditController", function($scope, $http, $state, $rootScope, $stateParams) {
        console.log("StateParams = ", $stateParams._id);
        $http.get("/api/v1/sites/" + $stateParams._id)
            .then(function(response) {
                $scope.site = response.data[0];
                console.log("Site = ", response.data[0]);
        });
        
        $scope.updateSite = function() {
            console.log("Updating Site");
            $scope.updating = "loading";
            
            $http.put("/api/v1/site", {
                // "name": $scope.site.name,
                "_id": $stateParams._id,
                "description": $scope.site.description,
                "adminUsername": $scope.site.username,
                "adminPassword": $scope.site.changePassword
                // "userName": $scope.username
            }).then(function(response) {
                $scope.updating = "";
                if (response.status < 400) {
                    // $scope.refresh();
                    console.log("site", response);
                    $state.go("sites.list");
                } else {
                    // alert("Error encountered " + response.status);
                    $rootScope.alerts.push({
                        "msg": "Unable to create site: " + response.data,
                        "type": "alert-danger"
                    });
                }
            }).catch(function(response) {
                $scope.updating = "";
                if (response.status == 402) {
                    $rootScope.alerts.push({
                        "msg": "Add or update your payment information to create another app",
                        "type": "alert-danger"
                    });
                    $scope.updating = "";
                    $state.go('account.billing');
                }
            })
            // $state.go("sites.create");
        }
    });
