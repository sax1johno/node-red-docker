angular.module("com.johnwoconnor.admin")
    .config(function (JSONEditorProvider) {
      var uploadFunction = function(type, file, cbs) {
        console.log("Type = ", type);
          if (type === 'root.upload_fail') {
            cbs.failure('Upload failed');
          } else {
            var url = '/upload';
            var xhr = new XMLHttpRequest();
            var fd = new FormData();
            xhr.open("POST", url, true);
            xhr.onreadystatechange = function() {
              console.log("state = ", xhr.readyState);
              console.log("status = ", xhr.status);
              if (xhr.readyState == xhr.HEADERS_RECEIVED) {
                cbs.updateProgress(0);
              }
              else if (xhr.readyState == 4 && xhr.status == 200) {
                    // Every thing ok, file uploaded
                    cbs.success(xhr.responseText);
                    console.log(xhr.responseText); // handle response.
              } else if (xhr.status >= 400) {
                console.log("Failed because of ", xhr.responseText);
                setTimeout(function() {
                  cbs.failure(xhr.responseText);
                }, 1);
                // cbs.failure(xhr.responseText);
              }
            };
            fd.append("attachment[file]", file);
            
            xhr.upload.addEventListener("progress", function (evt) {
              if (evt.lengthComputable) {
                cbs.updateProgress((evt.loaded / evt.total) * 100);            
              } else {
                cbs.updateProgress();
              }
            }, false);
             
            // File uploaded
            xhr.addEventListener("load", function () {
              // progressBarContainer.className += " uploaded";
              // progressBar.innerHTML = "Uploaded!";
              cbs.updateProgress();
            }, false);
                      
            xhr.send(fd);
        }
      };
          
      //     var tick = 0;
      //     var tickFunction = function() {
      //       tick += 1;
      //       console.log('progress: ' + tick);
      //       if (tick < 100) {
      //         cbs.updateProgress(tick);
      //         window.setTimeout(tickFunction, 50)
      //       } else if (tick == 100) {
      //         cbs.updateProgress();
      //         window.setTimeout(tickFunction, 500)
      //       } else {
      //       }
      //     };
      //     window.setTimeout(tickFunction)
      //   }
      // };
      
        JSONEditorProvider.configure({
            // plugins: {
            //     epiceditor: {
            //       basePath: "bower_components/EpicEditor/epiceditor"
            //     }
            // },
            defaults: {
                options: {
                    iconlib: 'bootstrap3',
                    theme: 'bootstrap3',
                    ajax: true,
                    no_additional_properties: true,
                    display_required_only: true,
                    upload: uploadFunction
                }
            },
        });
    })
    .controller("SchemaGeneratorController", function($scope, $http) {
      console.log("Inside of portfolio create controller");
      // Load with $http
      $scope.schema = $http.get('/api/admin/schema');
    })
    .controller('CreateButtonsController', function ($scope, $state, $http) {
      /**
       * Custom actions controller which allows you to add any other buttons/actions to the form.
       */
      $scope.save = function () {
        // console.log("Saving with value of ", $scope.editor.getValue());
        console.log($scope.editor.getValue());
        console.log(JSON.stringify($scope.editor.getValue()));
          // console.log('save data in sync controller', $scope.editor.getValue());
          // $http.post("/api/projects", $scope.editor.getValue()).then(function() {
          //   console.log("Uploaded");
          //   $state.go("portfolio");
          // }, function(err) {
          //   alert("Error saving project.  Check console for details");
          //   console.error(err);
          // });
      };
    })
    .controller('UpdateButtonsController', function ($scope, $state, $http) {
      /**
       * Custom actions controller which allows you to add any other buttons/actions to the form.
       */
      $scope.save = function () {
        // console.log("Saving with value of ", $scope.editor.getValue());
          // console.log('save data in sync controller', $scope.editor.getValue());
          $http.put("/api/projects", $scope.editor.getValue()).then(function() {
            console.log("Uploaded");
            $state.go("portfolio");
          }, function(err) {
            alert("Error saving project.  Check console for details");
            console.error(err);
          });
      };
    })