/*
	You can override configuration options by modifying the proplConfig object.
	You can add any configuration options that are valid for node-red, as well as custom propl
	settings.
*/
module.exports  = function(config) {
	// config.editorTheme.page.title = "Testing TEST TEST";
	// config.editorTheme.header.title = "Testing TEST TEST";
	// config.swagger.template.info.title = "My Swagger Title";
	// config.swagger.template.info.version = "1.0";
	// config.httpNodeMiddleware = function(req,res,next) { 
    //	// Perform any processing on the request.
    //	// Be sure to call next() if the request should be passed
    //	// to the relevant HTTP In node.
    // 	next();
	//};
	return config;
}